plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.example.reconciliation"; compileSdk = 35
    defaultConfig { applicationId = "com.example.reconciliation"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.apache.pdfbox:pdfbox-android:2.0.27.0")
    implementation("org.apache.poi:poi-ooxml:5.4.0")
}
