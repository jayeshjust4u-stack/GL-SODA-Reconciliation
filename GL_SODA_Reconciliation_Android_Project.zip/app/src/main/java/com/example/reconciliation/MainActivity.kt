package com.example.reconciliation

import android.app.*
import android.os.*
import android.content.*
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import org.apache.pdfbox.android.PDFBoxResourceLoader
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.text.PDFTextStripper
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

data class SodaRow(val part:String,val desc:String,val receipt:Double,val payment:Double,var used:Boolean=false)
data class GlRow(val date:String,val code:String,val desc:String,val deposit:Double,val withdrawal:Double)

class MainActivity: AppCompatActivity() {
    private val glUris=mutableListOf<Uri>(); private val sodaUris=mutableListOf<Uri>()
    private var masterUri:Uri?=null
    private lateinit var log:TextView
    private lateinit var progress:ProgressBar

    override fun onCreate(b:Bundle?) { super.onCreate(b); PDFBoxResourceLoader.init(applicationContext); buildUi() }

    private fun buildUi(){
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(28,24,28,24)
        val title=TextView(this); title.text="GL IT 2.0 ↔ SO Daily Account Reconciliation"; title.textSize=20f; title.setTypeface(null,1); root.addView(title)
        val info=TextView(this); info.text="Case-insensitive description matching • Receipt/Payment side ignored • Amount checked separately"; info.textSize=12f; root.addView(info)
        fun btn(t:String, f:()->Unit){ val x=Button(this); x.text=t; x.setOnClickListener{f()}; root.addView(x) }
        btn("SELECT GL IT 2.0 PDFs"){pickMany(10)}
        btn("SELECT SO DAILY ACCOUNT PDFs"){pickMany(11)}
        btn("SELECT GL MASTER EXCEL"){pickMaster()}
        btn("START RECONCILIATION"){start()}
        progress=ProgressBar(this); progress.visibility=View.GONE; root.addView(progress)
        log=TextView(this); log.textSize=11f; root.addView(ScrollView(this).apply{addView(log)})
        setContentView(root)
    }
    private fun pickMany(req:Int){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT); i.type="application/pdf"; i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,req) }
    private fun pickMaster(){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT); i.type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,12) }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d); if(c!=RESULT_OK||d==null)return
        if(r==10||r==11){ val list=if(d.clipData!=null)(0 until d.clipData!!.itemCount).map{d.clipData!!.getItemAt(it).uri}else listOfNotNull(d.data); if(r==10){glUris.clear();glUris.addAll(list)}else{sodaUris.clear();sodaUris.addAll(list)}; log.text="Selected GL PDFs: ${glUris.size}\nSelected SODA PDFs: ${sodaUris.size}"}
        if(r==12){masterUri=d.data; log.text="Master Excel selected."}
    }
    private fun norm(s:String)=s.trim().uppercase(Locale.ROOT).replace("–","-").replace("—","-").replace(Regex("\\s*-\\s*"),"-").replace(Regex("\\s+")," ")
    private fun money(s:String)=s.replace(",","").replace("₹","").trim().toDoubleOrNull()?:0.0
    private fun pdfText(uri:Uri):String{ val tmp=File(cacheDir,"t.pdf"); contentResolver.openInputStream(uri)!!.use{input->tmp.outputStream().use{input.copyTo(it)}}; PDDocument.load(tmp).use{PDFTextStripper().getText(it)} }
    private fun dateOf(t:String)=Regex("""Tran\s+Date\s*:\s*(\d{2}-\d{2}-\d{4})""",RegexOption.IGNORE_CASE).find(t)?.groupValues?.get(1)
        ?:Regex("""dated\s+(\d{2}-\d{2}-\d{4})""",RegexOption.IGNORE_CASE).find(t)?.groupValues?.get(1)?:""
    private fun parseGl(uri:Uri):Pair<String,List<GlRow>>{
        val t=pdfText(uri); val date=dateOf(t); val out=mutableListOf<GlRow>()
        t.lines().forEach{ line-> val m=Regex("""^\s*(\d+)\s+\d+\s+(\d{8,})\s+(.+?)\s+([\d,]+\.\d+)\s+([\d,]+\.\d+)\s*$""").find(line)
            if(m!=null) out.add(GlRow(date,m.groupValues[2],m.groupValues[3].trim(),money(m.groupValues[4]),money(m.groupValues[5]))) }
        return date to out
    }
    private fun parseSoda(uri:Uri):Pair<String,List<SodaRow>>{
        val t=pdfText(uri); val date=dateOf(t); val out=mutableListOf<SodaRow>(); var part="Unknown"
        t.lines().forEach{ raw-> val l=raw.trim(); Regex("""\bPART\s+([IVX]+)\b""",RegexOption.IGNORE_CASE).find(l)?.let{part="Part "+it.groupValues[1].uppercase()}
            val m=Regex("""^(\d+)\s+(.*?)\s+([\d,]+\.\d+)?\s*([\d,]+\.\d+)?$""").find(l) ?: return@forEach
            val desc=m.groupValues[2].trim(); if(desc.isBlank()||norm(desc).startsWith("TOTAL"))return@forEach
            val a=if(m.groupValues[3].isBlank())0.0 else money(m.groupValues[3]); val p=if(m.groupValues[4].isBlank())0.0 else money(m.groupValues[4])
            if(a==0.0&&p==0.0)return@forEach; out.add(SodaRow(part,desc,a,p))
        }; return date to out
    }
    private fun loadMaster():Map<String,Triple<String,String,String>>{
        val u=masterUri?:return emptyMap(); val tmp=File(cacheDir,"m.xlsx"); contentResolver.openInputStream(u)!!.use{input->tmp.outputStream().use{input.copyTo(it)}}; val wb=XSSFWorkbook(tmp.inputStream()); val sh=wb.getSheetAt(0)
        val h=sh.getRow(0); var code=-1;var desc=-1;var part=-1; for(c in 0 until h.lastCellNum){when(norm(h.getCell(c)?.stringCellValue?:"").replace(" ","_")){"ACCOUNT_CODE","ACCOUNTCODE"->code=c;"ACCOUNT_CODE_DESCRIPTION","ACCOUNT_DESCRIPTION"->desc=c;"PART","SODA_PART"->part=c}}
        val map=mutableMapOf<String,Triple<String,String,String>>(); for(r in 1..sh.lastRowNum){val d=sh.getRow(r)?.getCell(desc)?.toString()?:""; if(d.isNotBlank())map[norm(d)]=Triple(sh.getRow(r).getCell(code).toString(),d,sh.getRow(r).getCell(part).toString())}; wb.close(); return map
    }
    private fun start(){
        if(glUris.isEmpty()||sodaUris.isEmpty()||masterUri==null){Toast.makeText(this,"Select GL PDFs, SODA PDFs and Master Excel.",Toast.LENGTH_LONG).show();return}
        progress.visibility=View.VISIBLE; log.text="Starting reconciliation..."
        thread{try{val master=loadMaster(); val sodaByDate=sodaUris.map{it to parseSoda(it)}.groupBy{it.second.first}; val rows=mutableListOf<Array<Any?>>()
            glUris.forEachIndexed{idx,u-> val (date,gls)=parseGl(u); runOnUiThread{log.text="Processing ${idx+1}/${glUris.size}: $date"}; val soda=(sodaByDate[date]?.firstOrNull()?.second?.second?.toMutableList()?:mutableListOf())
                for(g in gls){val mi=master[norm(g.desc)]; val target=mi?.second?:g.desc; val s=soda.firstOrNull{!it.used&&norm(it.desc)==norm(target)}; if(s!=null)s.used=true
                    val sr=s?.receipt?:0.0;val sp=s?.payment?:0.0;val rd=g.deposit-sr;val pd=g.withdrawal-sp;val status=if(s==null)"NOT FOUND" else if(kotlin.math.abs(rd)<.005&&kotlin.math.abs(pd)<.005)"MATCH" else "DIFFERENCE"
                    rows.add(arrayOf(date,g.code,g.desc,s?.desc?:"",s?.part?:mi?.third?:"",g.deposit,g.withdrawal,sr,sp,rd,pd,status))}}
            val out=File(getExternalFilesDir(null),"GL_SODA_Reconciliation.xlsx"); writeXlsx(rows,out); runOnUiThread{progress.visibility=View.GONE;log.text="Completed.\n\nSaved:\n${out.absolutePath}"; share(out)}
        }catch(e:Exception){runOnUiThread{progress.visibility=View.GONE;log.text="ERROR: ${e.message}";Toast.makeText(this,"Error: ${e.message}",Toast.LENGTH_LONG).show()}}}
    }
    private fun writeXlsx(rows:List<Array<Any?>>,file:File){
        val wb=XSSFWorkbook(); val rec=wb.createSheet("Reconciliation"); val sum=wb.createSheet("Date Wise Summary")
        val headers=arrayOf("Date","IT 2.0 A/C Code","GL IT 2.0 Account Description","SODA Description","SODA Part","GL Deposit","GL Withdrawal","SODA Receipt","SODA Payment","Amount Difference Receipt","Amount Difference Payment","Status")
        headers.forEachIndexed{i,h->rec.createRow(0).createCell(i).setCellValue(h)}
        rows.forEachIndexed{ri,a->val r=rec.createRow(ri+1);a.forEachIndexed{ci,v->when(v){is Number->r.createCell(ci).setCellValue(v.toDouble());else->r.createCell(ci).setCellValue(v?.toString()?:"")}}}
        val sh=rows.groupBy{it[0].toString()}; val hs=arrayOf("Date","Total GL Entries","GL Deposit","SODA Receipt","Receipt Difference","GL Withdrawal","SODA Payment","Payment Difference","MATCH","DIFFERENCE","NOT FOUND"); hs.forEachIndexed{i,h->sum.createRow(0).createCell(i).setCellValue(h)}
        sh.entries.sortedBy{it.key}.forEachIndexed{ri,(d,g)->val r=sum.createRow(ri+1);val dep=g.sumOf{(it[5] as Number).toDouble()};val sr=g.sumOf{(it[7] as Number).toDouble()};val wd=g.sumOf{(it[6] as Number).toDouble()};val sp=g.sumOf{(it[8] as Number).toDouble()};val vals=arrayOf(d,g.size,dep,sr,dep-sr,wd,sp,wd-sp,g.count{it[11]=="MATCH"},g.count{it[11]=="DIFFERENCE"},g.count{it[11]=="NOT FOUND"});vals.forEachIndexed{ci,v->when(v){is Number->r.createCell(ci).setCellValue(v.toDouble());else->r.createCell(ci).setCellValue(v.toString())}}}
        for(s in arrayOf(rec,sum)){for(c in 0 until s.getRow(0).lastCellNum){s.setColumnWidth(c, minOf(55*256, maxOf(12*256,(s.getRow(0).getCell(c).stringCellValue.length+2)*256)))};s.freezePane(0,1)}; file.outputStream().use{wb.write(it)};wb.close()
    }
    private fun share(f:File){val uri=androidx.core.content.FileProvider.getUriForFile(this,"$packageName.provider",f);val i=Intent(Intent.ACTION_SEND);i.type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share report"))}
}